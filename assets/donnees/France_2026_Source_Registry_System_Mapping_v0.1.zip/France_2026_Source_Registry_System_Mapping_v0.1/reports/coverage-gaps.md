# Coverage Gaps — France-System-2026 v0.1

## A0 gaps
1. Advertising and online intermediation.
2. Transport/logistics infrastructure and operators.
3. Retail/food concentration and buyer power.
4. Construction/public-infrastructure groups.
5. 2026 company-level media ownership/voting rights.
6. Consolidated company-level public aid/guarantees.
7. Ultimate-beneficial-owner access where public data are restricted.

## A1 gaps
1. Person-to-organization governance network.
2. Public/private career circulation.
3. Think tanks, foundations and research/expertise funding.
4. Associations/NGOs and professional orders.
5. Major supplier/customer dependency networks.
6. Credit and insurance dependency at group level where data access permits.

## Rule
A gap remains a gap. It is never silently coded as zero power, zero coordination or zero dependence.
