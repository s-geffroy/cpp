# France 2026 Source Registry + System Mapping v0.1 — Audit

## Snapshot
**2026-08-12**

## Registry
Canonical sources registered: **53**.

A0 source routes are closed for the formal constitutional state, macro public finance, state ownership, banking, competition, procurement, media regulation, telecom, data, cybersecurity, energy, labor representation, health expertise, defense source discovery, EU fiscal/economic coordination, monetary policy and ECHR rights framework.

## First structural findings

### 1. France cannot be modeled as one hierarchical actor
The system contains national executive and legislature, constitutional/judicial review, territorial authorities, independent regulators, social partners, public and private firms, EU institutions, the Eurosystem and the ECHR system.

### 2. Fiscal footprint must be separated from ownership/control
Public spending is large, but state equity ownership is a distinct graph through the APE and public enterprises.

### 3. Regulation is polycentric
Banking, markets, competition, audiovisual, telecom, energy, personal data, medicines and health expertise are handled through distinct authorities with different legal statuses and European linkages.

### 4. Corporate-power mapping is technically feasible but requires multiple registries
RNE/DATA INPI, AMF filings, INSEE structural statistics, APE data, procurement open data, HATVP lobbying data and regulator sector datasets must be joined. Beneficial-owner access restrictions create a real evidence gap.

### 5. Media requires a five-layer model
Ownership, editorial governance, audience/exposure, distribution/platforms and advertising cannot be collapsed.

### 6. Social representation is plural
The system contains multiple nationally representative unions and hundreds of branch-level employer organizations. This must be tested empirically before any “corporatist” characterization.

### 7. Supranational allocation is mandatory
Euro-area monetary policy, EU fiscal/economic coordination and ECHR rights constraints cannot be attributed to the French executive.

## A0 gaps before full actor-level mapping
- advertising/intermediation market;
- transport/logistics;
- retail/food;
- construction/infrastructure;
- detailed 2026 media ownership update;
- company-by-company public-aid inventory;
- beneficial-owner completeness;
- people/governance/revolving-door graph;
- associations/NGOs/foundations and think-tank/expertise map.

## Decision
**Proceed to France Actor Registry + Corporate/Media/Finance Graph v0.1.**

No NSDAP similarity calculation is authorized yet.
