# France 2026 Source Registry + System Mapping v0.1

Snapshot: **2026-08-12**

- Sources: 53
- System nodes: 55
- Initial structural edges: 30
- Power dimensions: 15

This package creates the source and graph architecture for **France-System-2026**.
It deliberately does not calculate any NSDAP/France similarity.

Next phase: **France Actor Registry + Corporate/Media/Finance Graph v0.1**.
