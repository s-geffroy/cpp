# Source Admission Rules — France 2026

## Priority order
1. legal texts and official registers;
2. official statistics and regulator datasets;
3. audited corporate filings / AMF disclosures;
4. parliamentary inquiries and court records;
5. high-quality independent research for gaps;
6. press only for event discovery or where primary evidence is unavailable.

## Date rule
The snapshot is 12 August 2026. Later information is excluded from v0.1.

## Corporate provenance
For each group:
`legal entity → subsidiaries → ownership → voting rights → governance → financing → public contracts → subsidies → regulation → infrastructure → media/assets`

Ultimate beneficial ownership must not be guessed when the INPI beneficial-owner register is inaccessible.

## Media provenance
Separate:
`capital ownership → voting/control rights → editorial governance → audience → distribution → advertising → platforms/algorithms → primary sources/agencies`.

Ownership never proves editorial intervention.

## People/network provenance
A shared director, past employment, alumni relation, or membership creates only a `network_edge`.
It becomes `coordination`, `conflict`, `capture`, or `influence` only with independent evidence.
