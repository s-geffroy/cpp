# France-System-2026 — System Mapping Method v0.1

## Snapshot
Canonical snapshot date: **2026-08-12**.

No document, ownership change, appointment, policy, market-share observation, or institutional change occurring after this date may enter the snapshot without a new version.

## Object
The object is not merely “the French State”. It is **France-System-2026**:

`actors → resources → dependencies → relations → decisions → coercion → influence → beneficiaries/losers → counterpowers`

## Power is multidimensional
Never collapse the following into one variable:

- legal/normative power
- executive/administrative power
- fiscal power
- ownership power
- financial/credit power
- market power
- infrastructure power
- information/distribution power
- regulatory power
- judicial/review power
- labor/collective power
- expertise/norm-production power
- network/influence power
- coercive/security power
- supranational/external power

## Hard rules

1. **Public expenditure ≠ state control.**
2. **State ownership ≠ regulation ≠ procurement ≠ subsidy.**
3. **Market concentration ≠ domination** unless contestability and actual control are independently established.
4. **Network proximity ≠ coordination/collusion.**
5. **Lobbying contact ≠ capture.**
6. **Public funding of media ≠ governmental editorial control.**
7. **Platform distribution power ≠ media ownership.**
8. **Regulatory capacity ≠ political intent.**
9. **High health/social financing ≠ ownership of providers.**
10. **EU/ECB/ECHR constraints must be attributed to the supranational level, not to the French executive.**
11. **No local or sector-specific observation is extrapolated nationally without representativeness evidence.**
12. Every strong causal statement requires a documented mechanism and alternative explanations.

## Graph architecture

### Nodes
Formal institutions, regulators, public firms, private firms, banks, insurers, media, platforms, infrastructure operators, social partners, expertise institutions, civil society, external institutions.

### Edges
Ownership, appointment, budget funding, procurement, subsidy, credit, insurance, regulation, licensing, judicial review, lobbying, collective bargaining, information distribution, platform ranking, personnel mobility, expertise input, supranational constraint.

### Edge evidence statuses
- P4: direct official/primary evidence
- P3: strong corroborated evidence
- P2: probable
- P1: plausible/contested
- P0: unproven

Edges marked only by proximity or common membership cannot be upgraded to coordination without independent evidence.
