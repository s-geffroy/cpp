# Corporate and Power Graph Rules

## Required entity identifiers
Prefer SIREN/SIRET, LEI, EUID, AMF issuer identifier, or official registry keys.

## Ownership
Store:
- direct shareholding %
- voting-right %
- control status
- date
- source
- uncertainty

Do not infer ultimate control solely from brand identity.

## Financial dependence
Keep independent:
- bank credit
- bonds
- equity
- state guarantees
- subsidies
- procurement revenue
- insurance/reinsurance
- major customers/suppliers
- regulated-network access

## Market power
Use HHI/market shares/entry barriers/substitution where official data exist.
Large turnover alone is not market power.

## State-business coordination
Code separately:
- state → firm direction
- firm → state influence
- mutual dependence
- formal collective coordination
- regulatory capture (only if independently evidenced)

## Corporatism test
A corporatist label requires all of:
1. institutionalized interest representation,
2. structured relation to state decision-making,
3. decision/implementation role,
4. measured autonomy of represented organizations.
Mere existence of unions, employer federations, regulation or large firms is insufficient.
